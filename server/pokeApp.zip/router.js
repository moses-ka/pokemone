import express from 'express';
import poke from './db.js';
const route = express.Router();
route.get('/', async(req, res) => {
  try {
    const pokemon = await poke.find();
    res.status(200).send(pokemon)
  } catch (error) {
    res.status(404).send(error)
  }
})
route.get('/:id', async(req, res) => {
    res.send('welcom to /:id')
})
route.get('/:id/:name', async(req, res) => {
    res.send('welcome to id/:name')
})

export default route